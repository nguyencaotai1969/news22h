Change Log :

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.1 ==
- [IMPROVEMENT] Add hook filter for number format of post view counter

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.3 ==
- [IMPROVEMENT] Only track single post type

== 1.0.2 ==
- [IMPROVEMENT] Prevent plugin conflict by changing ajax_url variable name

== 1.0.1 ==
- [BUG] Fix view counter query issue

== 1.0.0 ==
- First Release
