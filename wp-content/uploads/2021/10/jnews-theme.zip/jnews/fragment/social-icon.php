<div class="jeg_nav_item">
	<ul class="jeg_top_socials">
	    <?php jnews_generate_social_icon(); ?>
	</ul>
</div>