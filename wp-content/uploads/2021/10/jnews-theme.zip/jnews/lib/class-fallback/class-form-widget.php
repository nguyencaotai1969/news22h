<?php
/**
 * @author : Jegtheme
 */

namespace Jeg\Form;

class Form_Widget {

	public function __construct() {}

	public static function render_form( $id, $segments, $fields ) {}
}
